int convert_geo_vec(double lat_in,double lon_in, double height_in, double th_in, double ph_in,
	double *lat_out, double *lon_out, double *th1_out, double *ph1_out, double *th2_out, double *ph2_out);
